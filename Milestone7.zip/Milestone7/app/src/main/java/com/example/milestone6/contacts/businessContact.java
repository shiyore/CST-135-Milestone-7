package com.example.milestone6.contacts;

import java.util.Scanner;

public class businessContact extends baseContact{
	private String hours , URL ;

	public businessContact() {		
		/**super();
		hours = "";
		URL = "";
		super.Business = true;**/
	}
	public businessContact(String pic , String name , String email , String number , String street, String city, String state, String zip , String country, boolean isFavorite , String hours , String URL , int uses) {
		super(pic, name , email , number, street , city, state, zip , country, isFavorite , uses);
		this.hours = hours;
		this.URL = URL;
	}
	public void constructContact() {
		Scanner input = new Scanner(System.in);
		System.out.print("Pic: ");
		setPic(input.nextLine());
		System.out.print("\nName: ");
		setName(input.nextLine());
		System.out.print("\nEmail: ");
		setEmail(input.nextLine());
		System.out.print("\nNumber: ");
		setNumber(input.nextLine());
		System.out.print("\nStreet: ");
		setStreet(input.nextLine());
		System.out.print("\nCity: ");
		setCity(input.nextLine());
		System.out.print("\nState: ");
		setState(input.nextLine());
		System.out.print("\nZIP code: ");
		setZip(input.nextLine());
		System.out.print("\nCountry: ");
		setCountry(input.nextLine());
		System.out.print("\nHours: ");
		hours = input.nextLine();
		System.out.print("\nURL: ");
		URL = input.nextLine();
	}
	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		//System.out.println("Changing hours of " + getName() + " to " + hours);
		this.hours = hours;
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String uRL) {
		//System.out.println("Changing URL of " + getName() + " to " + uRL);
		URL = uRL;
	}
	
	//concept method for later implementation to open browser to website URL
	public void navigateTo() {
		System.out.println("Navigatiing to " + getName() + "'s website: " + getURL());
	}
	
	public void editContact(businessContact contact) {
			Scanner input =  new Scanner(System.in);
			String temp = "";
			boolean exit = false;
			int num = 15;
			do{
				System.out.printf("\nWhat would you like to edit?: \n(1)Pic: %s\n(2)Name: %s \n(3)Email: %s \n(4)Number: %s \n(5)Street %s \n(6)City: %s \n(7)State: %s \n(8)ZIP: %s\n(9)Country: %s \n(10)Favorite: "+contact.isFavorite()+"\n(11)Birthday: %s \n(12)Description: %s\n(0)Exit\n", contact.getPic() , contact.getName(), contact.getEmail() , contact.getNumber(), contact.getStreet() , contact.getCity() , contact.getState() , contact.getZip(), contact.getCountry() , contact.getHours(), contact.getURL());
				System.out.print("What would you like to edit? (1-12):");
				try {
					num = input.nextInt();
					input.nextLine();
				}catch(Error e) {
					System.out.println("Please input a valid integer");
				}
				switch(num) {
				case 1:
					System.out.print("\nWhat would you like to change the pic to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setPic(temp);
					break;
				case 2:
					System.out.print("\nWhat would you like to change the name to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setName(temp);
					break;
				case 3:
					System.out.print("\nWhat would you like to change the email to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setEmail(temp);
					break;
				case 4:
					System.out.print("\nWhat would you like to change the number to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setNumber(temp);
					break;
				case 5:
					System.out.print("\nWhat would you like to change the street to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setStreet(temp);
					break;
				case 6:
					System.out.print("\nWhat would you like to change the city to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setCity(temp);
					break;
				case 7:
					System.out.print("\nWhat would you like to change the state to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setState(temp);
					break;
				case 8:
					System.out.print("\nWhat would you like to change the ZIP code to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setZip(temp);
					break;
				case 9:
					System.out.print("\nWhat would you like to change the country to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setCountry(temp);
					break;
				case 10:
					boolean stay = true;
					do {
						System.out.print("\nWould you like this persone to be a favorite?(y/n): ");
						temp = input.nextLine();
						//input.nextLine();
						if(temp.toLowerCase().charAt(0) == 'y') {
							stay = false;
							contact.setFavorite(true);
						}
						else if(temp.toLowerCase().charAt(0) == 'n') {
							stay = false;
							contact.setFavorite(false);
						}
						else {
							System.out.println("\nPlease input yes or no.");
						}
					}while(stay);
					break;
				case 11:
					System.out.print("\nWhat would you like to change the hours to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setHours(temp);
					break;
				case 12:
					System.out.print("\nWhat would you like to change the URL to?: ");
					temp = input.nextLine();
					//input.nextLine();
					contact.setURL(temp);
					break;
				case 0:
					exit = true;
					break;
					
				}
					
			}while(!exit);
	}
}
