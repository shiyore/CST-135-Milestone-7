package com.example.milestone6.contacts;
import java.util.*;
public class contactList {
	private ArrayList<baseContact> contacts = new ArrayList<>();
	
	
	public contactList() {
		
	}
	public contactList(HashMap<String,baseContact> contactMap) {
		for (Map.Entry<String, baseContact> n : contactMap.entrySet()) {
			if(n.getValue().isFavorite())
				contacts.add(n.getValue());
		}
	}
	
	//getters and setters
	public ArrayList<baseContact> getContacts() {
		return contacts;
	}
	public void setContacts(ArrayList<baseContact> contacts) {
		this.contacts = contacts;
	}
	public void setContactsFromMap(Map<String, baseContact> map) {
		contacts = new ArrayList<>();
		for (Map.Entry<String, baseContact> n : map.entrySet()) {
			contacts.add(n.getValue());
		}
	}
}
