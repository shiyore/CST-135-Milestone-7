package com.example.milestone6;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.milestone6.IO.businessService;
import com.example.milestone6.contacts.baseContact;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class MostUsedAdapter extends BaseAdapter {

    Activity mActivity;
    businessService BService;
    List<baseContact> mostUsed;

    private static int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
    private static List<baseContact> top3(List<baseContact> input){
        ArrayList<baseContact> temp = new ArrayList<>();
        baseContact first , second , third;
        first = new baseContact();
        second = new baseContact();
        third = new baseContact();
        for(baseContact n : input) {
            if(n.getUses() > third.getUses()) {
                if(n.getUses() > second.getUses()) {
                    if(n.getUses() > first.getUses()) {
                        first = n;
                    }
                    else {
                        if(second.getUses() == n.getUses()) {

                        }
                        else {
                            second = n;
                        }
                    }
                }
                else {
                    if(third.getUses() == n.getUses()) {

                    }
                    else {
                        third = n;
                    }
                }
            }
        }
        temp.add(first);
        temp.add(second);
        temp.add(third);
        System.out.println("Temp: " + temp);
        return temp;
    }

    /**public static void main(String[] args) {
        // TODO Auto-generated method stub
        ArrayList<Integer> nums = new ArrayList<>();
        Random random = new Random();
        for(int i = 0 ; i < 20 ; i++) {
            nums.add(getRandomNumberInRange(1 , 30));
        }
        System.out.println(nums);
        System.out.println(top3(nums));

    }**/
    public MostUsedAdapter(Activity mActivity, businessService BService) {
        this.mActivity = mActivity;
        this.BService = BService;
        mostUsed = top3(BService.getContactList());
    }

    @Override
    public int getCount() {
        return mostUsed.size();
    }

    @Override
    public baseContact getItem(int position) {
        return mostUsed.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View onePersonLine;

        LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        onePersonLine = inflater.inflate(R.layout.contact_oneline , parent , false);

        TextView tv_name = onePersonLine.findViewById(R.id.tv_name);
        TextView tv_numberVal = onePersonLine.findViewById(R.id.tv_numberVal);

        baseContact contact = this.getItem(position);

        tv_name.setText(contact.getName());
        tv_numberVal.setText(contact.numberWithDashes());

        return onePersonLine;
    }
}
