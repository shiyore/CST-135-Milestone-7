package com.example.milestone6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class newBusinessContact extends AppCompatActivity{
    Button b_okay , b_cancel , b_delete , btn_callb , btn_textb , btn_mapsb , btn_web , btn_emailb;
    EditText et_name , et_number , et_field1 , et_field2 , et_email,et_street , et_city, et_state, et_zip , et_country;
    int positionToEdit = -1;
    final static int PERMISSION_TO_CALL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_contact);

        b_okay = findViewById(R.id.b_submit);
        b_cancel = findViewById(R.id.b_cancel);
        et_name = findViewById(R.id.et_name);
        et_number = findViewById(R.id.et_number);
        et_field1 = findViewById(R.id.et_field1);
        et_field2 = findViewById(R.id.et_field2);
        et_email = findViewById(R.id.et_email);
        et_street = findViewById(R.id.et_street);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        et_zip = findViewById(R.id.et_zip);
        et_country = findViewById(R.id.et_country);
        b_delete = findViewById(R.id.b_delete);
        btn_callb = findViewById(R.id.btn_callb);
        btn_textb = findViewById(R.id.btn_txtb);
        btn_mapsb = findViewById(R.id.btn_mapsb);
        btn_emailb = findViewById(R.id.btn_emailb);
        btn_web = findViewById(R.id.btn_web);

        //listen for data
        Bundle incomingIntent = getIntent().getExtras();

        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            String number  = incomingIntent.getString("number");
            String field1  = incomingIntent.getString("field1");
            String field2  = incomingIntent.getString("field2");
            String email  = incomingIntent.getString("email");
            String street  = incomingIntent.getString("street");
            String city  = incomingIntent.getString("city");
            String state  = incomingIntent.getString("state");
            String zip  = incomingIntent.getString("zip");
            String country  = incomingIntent.getString("country");
            int uses = incomingIntent.getInt("uses");

            et_name.setText(name);
            et_number.setText(number);
            et_field1.setText(field1);
            et_field2.setText(field2);
            et_email.setText(email);
            et_street.setText(street);
            et_city.setText(city);
            et_state.setText(state);
            et_zip.setText(zip);
            et_country.setText(country);

            positionToEdit = incomingIntent.getInt("edit");
        }

        b_okay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //get info from text fields
                String newName = et_name.getText().toString();
                String newNumber  = et_number.getText().toString();
                String newField1  = et_field1.getText().toString();
                String newField2  = et_field2.getText().toString();
                String newEmail  = et_email.getText().toString();
                String newStreet  = et_street.getText().toString();
                String newCity  = et_city.getText().toString();
                String newState  = et_state.getText().toString();
                String newZip  = et_zip.getText().toString();
                String newCountry  = et_country.getText().toString();
                

                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("edit" , positionToEdit);
                i.putExtra("name" , newName);
                i.putExtra("number" , newNumber);
                i.putExtra("field1" , newField1);
                i.putExtra("field2" , newField2);
                i.putExtra("email" , newEmail);
                i.putExtra("street" , newStreet);
                i.putExtra("city" , newCity);
                i.putExtra("state" , newState);
                i.putExtra("zip" , newZip);
                i.putExtra("country" , newCountry);
                i.putExtra("type" , "business");

                startActivity(i);
            }
        });
        b_cancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),MainActivity.class);
                startActivity(i);
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        b_delete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //get info from text fields
                String newName = et_name.getText().toString();
                String newNumber  = et_number.getText().toString();
                String newField1  = et_field1.getText().toString();
                String newField2  = et_field2.getText().toString();
                String newEmail  = et_email.getText().toString();
                String newStreet  = et_street.getText().toString();
                String newCity  = et_city.getText().toString();
                String newState  = et_state.getText().toString();
                String newZip  = et_zip.getText().toString();
                String newCountry  = et_country.getText().toString();

                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("edit" , positionToEdit);
                i.putExtra("name" , newName);
                i.putExtra("number" , newNumber);
                i.putExtra("field1" , newField1);
                i.putExtra("field2" , newField2);
                i.putExtra("email" , newEmail);
                i.putExtra("street" , newStreet);
                i.putExtra("city" , newCity);
                i.putExtra("state" , newState);
                i.putExtra("zip" , newZip);
                i.putExtra("country" , newCountry);
                i.putExtra("type" , "delete");

                startActivity(i);
            }
        });
        btn_web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWebPage(et_field2.getText().toString());
            }
        });
        btn_emailb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String [] addresses = new String[1];
                addresses[0] = et_email.getText().toString();
                composeEmail(addresses , "Hello from anon");
            }
        });
        btn_callb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialPhoneNumber(et_number.getText().toString());
            }
        });
        btn_textb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                composeMmsMessage(et_number.getText().toString() , "Yo, lets talk");
            }
        });
        btn_mapsb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String address = ""+et_street.getText().toString() + ", " + et_zip.getText().toString() + " " + et_city.getText().toString() + " " + et_state.getText().toString();
                String mapsQuery = "geo:0,0?q="+address;
                Uri mapUri = Uri.parse(mapsQuery);
                showMap(mapUri);
            }
        });

    }
    public void showMap(Uri geoLocation) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(geoLocation);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void composeMmsMessage(String phoneNumber, String message) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + phoneNumber));  // This ensures only SMS apps respond
        intent.putExtra("sms_body", message);
        //intent.putExtra(Intent.EXTRA_STREAM, attachment);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    public void openWebPage(String url) {
        if(!url.startsWith("http://") || !url.startsWith("https://")){
            url = "http://" + url;
        }
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void dialPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
    public void callPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phoneNumber));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            // No explanation needed; request the permission
            ActivityCompat.requestPermissions(newBusinessContact.this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    PERMISSION_TO_CALL);

        }
        else {

            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_TO_CALL: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    callPhoneNumber(et_number.getText().toString());
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this , "Cannot make a call wihtout your permission" , Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }
}
