package com.example.milestone6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DecideContactType extends AppCompatActivity {

    Button b_person , b_business;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.decide_contact_type);

        b_person = findViewById(R.id.b_person);
        b_business = findViewById(R.id.b_business);

        b_person.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),newPersonContact.class);
                startActivity(i);
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        b_business.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),newBusinessContact.class);
                startActivity(i);
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
