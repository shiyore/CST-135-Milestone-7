package com.example.milestone6.IO;

import android.content.Context;

import com.example.milestone6.contacts.baseContact;

import java.util.List;

public class businessService {
	private addressBook contacts;
	private fileIOService IO;
	private List<baseContact> contactList;
	
	public businessService() {
		contacts  = new addressBook();
		//IO  = new fileIOService(getApplicationContext());
		contactList = contacts.sortBy("name" , true);
		
	}
	public businessService(addressBook contacts) {
		this.contacts  = contacts;
		//IO  = new fileIOService();
		contactList = this.contacts.sortBy("name" , true);
		
	}
	
	public void saveContacts(Context context) {
		DataAccessService das = new fileIOService(context);
		das.writeAllData(contacts);
	}
	public void loadContacts(Context context) {
		IO = new fileIOService(context);
		contacts.setContacts(IO.readAllData().getContacts());
	}
	
	//getters and setters for the addressbook
	public addressBook getAddressBook() {
		return contacts;
	}
	public List<baseContact> getContactList(){return contactList; }
	public void updateContactList(){contactList = contacts.sortBy("name" , true);}
	public void setAddressBook(addressBook contacts) {
		this.contacts = contacts;
	}
	public void setContactList(List<baseContact> contacts){contactList = contacts;}
}
