package com.example.milestone6;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.milestone6.contacts.*;
import com.example.milestone6.IO.*;


public class PersonAdapter extends BaseAdapter {

    Activity mActivity;
    businessService BService;

    public PersonAdapter(Activity mActivity, businessService BService) {
        this.mActivity = mActivity;
        this.BService = BService;
    }

    @Override
    public int getCount() {
        return BService.getContactList().size();
    }

    @Override
    public baseContact getItem(int position) {
        return BService.getContactList().get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View onePersonLine;

        LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        onePersonLine = inflater.inflate(R.layout.contact_oneline , parent , false);

        TextView tv_name = onePersonLine.findViewById(R.id.tv_name);
        TextView tv_numberVal = onePersonLine.findViewById(R.id.tv_numberVal);

        baseContact contact = this.getItem(position);

        tv_name.setText(contact.getName());
        tv_numberVal.setText(contact.numberWithDashes());

        return onePersonLine;
    }
}
